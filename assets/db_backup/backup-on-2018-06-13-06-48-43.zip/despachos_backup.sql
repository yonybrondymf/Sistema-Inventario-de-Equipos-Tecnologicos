#
# TABLE STRUCTURE FOR: antivirus
#

DROP TABLE IF EXISTS `antivirus`;

CREATE TABLE `antivirus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `antivirus` (`id`, `descripcion`, `estado`) VALUES ('1', 'Nod 32', '1');
INSERT INTO `antivirus` (`id`, `descripcion`, `estado`) VALUES ('2', 'Avast 8', '0');
INSERT INTO `antivirus` (`id`, `descripcion`, `estado`) VALUES ('3', 'Karpesky 7', '0');


#
# TABLE STRUCTURE FOR: areas
#

DROP TABLE IF EXISTS `areas`;

CREATE TABLE `areas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('1', 'Recursos Humanos', '1');
INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('2', 'Contabilidad', '0');
INSERT INTO `areas` (`id`, `nombre`, `estado`) VALUES ('3', 'Samsung', '0');


#
# TABLE STRUCTURE FOR: computadoras
#

DROP TABLE IF EXISTS `computadoras`;

CREATE TABLE `computadoras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `presentacion_id` int(11) NOT NULL,
  `proveedor_id` int(11) NOT NULL,
  `finca_id` int(11) NOT NULL,
  `area_id` int(11) NOT NULL,
  `contacto` varchar(250) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `procesador_id` int(11) NOT NULL,
  `ram_id` int(11) NOT NULL,
  `disco_id` int(11) NOT NULL,
  `so_id` int(11) NOT NULL,
  `serial_so` int(11) NOT NULL,
  `office_id` int(11) NOT NULL,
  `serial_office` int(11) NOT NULL,
  `antivirus_id` int(11) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `mac` varchar(50) NOT NULL,
  `bitacora` text NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` date DEFAULT NULL,
  `fecregistro` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `computadoras` (`id`, `codigo`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`) VALUES ('1', '9121', '1', '2', '1', '2', 'Jose Perez', '1', '1', '2', '1', '1', '1010212', '1', '11221', '2', '192.168.1.1', '12123121', 'Esta todo ok', '1', '2018-06-11', '2018-06-11 07:09:11');
INSERT INTO `computadoras` (`id`, `codigo`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`) VALUES ('2', '99112', '2', '1', '1', '1', 'Maria Cortez', '2', '1', '1', '1', '2', '120011', '1', '101212', '2', '192.168.1.1', '12123121', 'esta funcionable', '1', '2018-06-11', '2018-06-11 04:21:16');
INSERT INTO `computadoras` (`id`, `codigo`, `presentacion_id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `procesador_id`, `ram_id`, `disco_id`, `so_id`, `serial_so`, `office_id`, `serial_office`, `antivirus_id`, `ip`, `mac`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`) VALUES ('3', '991', '2', '2', '1', '2', 'juan Cortez', '1', '1', '2', '1', '1', '121212', '1', '12131', '1', '192.168.1.1', '112-11111', 'Too esta funcionando', '1', '2018-06-13', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: computadoras_mantenimientos
#

DROP TABLE IF EXISTS `computadoras_mantenimientos`;

CREATE TABLE `computadoras_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computadora_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `computadoras_mantenimientos` (`id`, `computadora_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('1', '1', '2018-06-11', 'Jose Luis Fernandez', 'Cambio de pila');
INSERT INTO `computadoras_mantenimientos` (`id`, `computadora_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('2', '1', '2018-06-11', 'Jhon Manrique', 'Cambio de Memoria');
INSERT INTO `computadoras_mantenimientos` (`id`, `computadora_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('3', '2', '2018-06-11', 'Jose Luis Fernandez', 'Cambio de Respuesto');
INSERT INTO `computadoras_mantenimientos` (`id`, `computadora_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('4', '3', '2018-06-13', 'Jose Martinez', 'Limpieza interna');


#
# TABLE STRUCTURE FOR: discos
#

DROP TABLE IF EXISTS `discos`;

CREATE TABLE `discos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `capacidad` varchar(250) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `discos` (`id`, `capacidad`, `fabricante_id`, `estado`) VALUES ('1', '1024 mb', '1', '1');


#
# TABLE STRUCTURE FOR: fabricantes
#

DROP TABLE IF EXISTS `fabricantes`;

CREATE TABLE `fabricantes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `fabricantes` (`id`, `nombre`, `estado`) VALUES ('1', 'Chipset ', '0');
INSERT INTO `fabricantes` (`id`, `nombre`, `estado`) VALUES ('2', 'Intel', '1');


#
# TABLE STRUCTURE FOR: fincas
#

DROP TABLE IF EXISTS `fincas`;

CREATE TABLE `fincas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nit` int(11) NOT NULL,
  `nombre` varchar(250) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `descripcion` text NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('1', '10012', 'Finca 1', 'Direccion de la Finca 01', '053464642', 'Esta es la finca 01', '1');


#
# TABLE STRUCTURE FOR: impresoras
#

DROP TABLE IF EXISTS `impresoras`;

CREATE TABLE `impresoras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) NOT NULL,
  `finca_id` int(11) NOT NULL,
  `area_id` int(11) NOT NULL,
  `contacto` varchar(150) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `serial_fabricante` int(11) NOT NULL,
  `bitacora` text NOT NULL,
  `codigo` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` date DEFAULT NULL,
  `fecregistro` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `impresoras` (`id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `referencia`, `serial_fabricante`, `bitacora`, `codigo`, `estado`, `ultimo_mante`, `fecregistro`) VALUES ('1', '1', '1', '2', 'Jose Perez', '1', 'refencia 01', '12129991', 'Esta todo bueno', '100143', '1', '0000-00-00', '2018-06-10 01:15:08');
INSERT INTO `impresoras` (`id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `referencia`, `serial_fabricante`, `bitacora`, `codigo`, `estado`, `ultimo_mante`, `fecregistro`) VALUES ('2', '2', '1', '1', 'Jose Perez', '1', 'refencia 01', '12129992', 'equipo funcionable', '100143', '1', '0000-00-00', '2018-06-10 07:22:40');
INSERT INTO `impresoras` (`id`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `referencia`, `serial_fabricante`, `bitacora`, `codigo`, `estado`, `ultimo_mante`, `fecregistro`) VALUES ('3', '1', '1', '2', 'Jose Perez', '2', 'referencia de la impresora 01', '11201212', 'esta funcionable', '10012', '1', '2018-06-11', '2018-06-11 01:06:06');


#
# TABLE STRUCTURE FOR: impresoras_mantenimientos
#

DROP TABLE IF EXISTS `impresoras_mantenimientos`;

CREATE TABLE `impresoras_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `impresora_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `impresoras_mantenimientos` (`id`, `impresora_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('1', '3', '2018-06-11', 'Jhon Manrique', 'Cambio de Cartuchos');


#
# TABLE STRUCTURE FOR: lectores
#

DROP TABLE IF EXISTS `lectores`;

CREATE TABLE `lectores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `descripcion` text NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` date NOT NULL,
  `fecregistro` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `lectores` (`id`, `codigo`, `fabricante_id`, `modelo`, `descripcion`, `estado`, `ultimo_mante`, `fecregistro`) VALUES ('1', '122', '1', 'modelo del lector 1', 'descripcion del lector 1', '1', '2018-06-11', '2018-06-12 14:32:29');


#
# TABLE STRUCTURE FOR: lectores_mantenimientos
#

DROP TABLE IF EXISTS `lectores_mantenimientos`;

CREATE TABLE `lectores_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lector_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `lectores_mantenimientos` (`id`, `lector_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('1', '1', '2018-06-11', 'Jose Luis Fernandez', 'cambiode lector');


#
# TABLE STRUCTURE FOR: logs
#

DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` datetime NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `modulo` varchar(200) NOT NULL,
  `accion` varchar(200) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('1', '2018-06-13 05:05:38', '1', 'Usuarios', '', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('2', '2018-06-13 05:05:45', '1', 'Usuarios', '', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('3', '2018-06-13 05:14:54', '1', 'Computadoras', '', 'Inserción de nueva Computadora con Codigo 0991');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('4', '2018-06-13 05:15:15', '1', 'Computadoras', '', 'Actualización de la Computadora con Codigo 991');
INSERT INTO `logs` (`id`, `fecha`, `usuario_id`, `modulo`, `accion`, `descripcion`) VALUES ('5', '2018-06-13 05:15:39', '1', 'Computadoras', '', 'Registro de Mantenimiento a la Computadora con Codigo 991');


#
# TABLE STRUCTURE FOR: memorias
#

DROP TABLE IF EXISTS `memorias`;

CREATE TABLE `memorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `capacidad` varchar(250) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `memorias` (`id`, `capacidad`, `fabricante_id`, `estado`) VALUES ('1', '4000 mb', '1', '1');
INSERT INTO `memorias` (`id`, `capacidad`, `fabricante_id`, `estado`) VALUES ('2', '8000 mb', '1', '0');


#
# TABLE STRUCTURE FOR: monitores
#

DROP TABLE IF EXISTS `monitores`;

CREATE TABLE `monitores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `tamaño` varchar(100) NOT NULL,
  `proveedor_id` int(11) NOT NULL,
  `finca_id` int(11) NOT NULL,
  `area_id` int(11) NOT NULL,
  `contacto` varchar(250) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `serial_fabricante` varchar(100) NOT NULL,
  `referencia` varchar(100) NOT NULL,
  `bitacora` text NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` text,
  `fecregistro` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`) VALUES ('1', '19122', '19\' pulgadas', '1', '1', '2', 'Jose Perez', '1', '11201212', 'referencia de la monior 01', 'esta funcionable', '1', '2018-06-11', '2018-06-10 03:08:09');
INSERT INTO `monitores` (`id`, `codigo`, `tamaño`, `proveedor_id`, `finca_id`, `area_id`, `contacto`, `fabricante_id`, `serial_fabricante`, `referencia`, `bitacora`, `estado`, `ultimo_mante`, `fecregistro`) VALUES ('2', '10012', '19\' pulgadas', '2', '1', '1', 'Maria Cortez', '1', '11201212', 'refencia 01', 'esta funcionable', '1', '2018-06-11', '2018-06-11 08:26:22');


#
# TABLE STRUCTURE FOR: monitores_mantenimientos
#

DROP TABLE IF EXISTS `monitores_mantenimientos`;

CREATE TABLE `monitores_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `monitor_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `monitores_mantenimientos` (`id`, `monitor_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('1', '1', '2018-06-14', 'Jose Luis Fernandez Aguilar', 'Limpieza interna');
INSERT INTO `monitores_mantenimientos` (`id`, `monitor_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('2', '2', '2018-06-11', 'Jhon Manrique', 'Limpieza interna');
INSERT INTO `monitores_mantenimientos` (`id`, `monitor_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('3', '1', '2018-06-11', 'Jhon Manrique', 'Cambio de Repuesto');


#
# TABLE STRUCTURE FOR: office
#

DROP TABLE IF EXISTS `office`;

CREATE TABLE `office` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `office` (`id`, `nombre`, `estado`) VALUES ('1', 'Office 2013', '1');
INSERT INTO `office` (`id`, `nombre`, `estado`) VALUES ('2', 'Office 2016', '0');


#
# TABLE STRUCTURE FOR: presentaciones
#

DROP TABLE IF EXISTS `presentaciones`;

CREATE TABLE `presentaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `presentaciones` (`id`, `nombre`, `estado`) VALUES ('1', 'Presentacion 01', '1');
INSERT INTO `presentaciones` (`id`, `nombre`, `estado`) VALUES ('2', 'Presentacion 2', '0');


#
# TABLE STRUCTURE FOR: procesadores
#

DROP TABLE IF EXISTS `procesadores`;

CREATE TABLE `procesadores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `referencia` varchar(250) NOT NULL,
  `velocidad` varchar(250) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `procesadores` (`id`, `referencia`, `velocidad`, `fabricante_id`, `estado`) VALUES ('1', 'refencia 01', '100 mb', '1', '1');


#
# TABLE STRUCTURE FOR: proveedores
#

DROP TABLE IF EXISTS `proveedores`;

CREATE TABLE `proveedores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) NOT NULL,
  `nit` varchar(100) NOT NULL,
  `direccion` varchar(250) NOT NULL,
  `correo` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `proveedores` (`id`, `nombre`, `nit`, `direccion`, `correo`, `estado`) VALUES ('1', 'Proveedor 01', '120121', 'Calle Pichincha 310', 'proveedor@gmail.com', '1');
INSERT INTO `proveedores` (`id`, `nombre`, `nit`, `direccion`, `correo`, `estado`) VALUES ('2', 'Proveedor 2', '', '', '', '0');


#
# TABLE STRUCTURE FOR: proyectores
#

DROP TABLE IF EXISTS `proyectores`;

CREATE TABLE `proyectores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `descripcion` text NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` date DEFAULT NULL,
  `fecregistro` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `proyectores` (`id`, `codigo`, `fabricante_id`, `modelo`, `descripcion`, `estado`, `ultimo_mante`, `fecregistro`) VALUES ('1', '100143', '1', 'modelo proyector 1', 'Descripcion del proyector 1', '1', '2018-06-11', '2018-06-03 12:30:24');


#
# TABLE STRUCTURE FOR: proyectores_mantenimientos
#

DROP TABLE IF EXISTS `proyectores_mantenimientos`;

CREATE TABLE `proyectores_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proyector_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` date NOT NULL,
  `descripcion` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `proyectores_mantenimientos` (`id`, `proyector_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('1', '1', '2018-06-11', '0000-00-00', 'Cambio de Ventilador');


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `roles` (`id`, `nombre`, `descripcion`) VALUES ('1', 'Administrador', '');
INSERT INTO `roles` (`id`, `nombre`, `descripcion`) VALUES ('2', 'Usuario', '');


#
# TABLE STRUCTURE FOR: sistemas
#

DROP TABLE IF EXISTS `sistemas`;

CREATE TABLE `sistemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(100) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `sistemas` (`id`, `descripcion`, `estado`) VALUES ('1', 'Windows 8', '1');
INSERT INTO `sistemas` (`id`, `descripcion`, `estado`) VALUES ('2', 'Windows 10', '1');


#
# TABLE STRUCTURE FOR: tablets
#

DROP TABLE IF EXISTS `tablets`;

CREATE TABLE `tablets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` int(11) NOT NULL,
  `fabricante_id` int(11) NOT NULL,
  `modelo` varchar(100) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `ultimo_mante` date DEFAULT NULL,
  `fecregistro` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tablets` (`id`, `codigo`, `fabricante_id`, `modelo`, `descripcion`, `estado`, `ultimo_mante`, `fecregistro`) VALUES ('1', '10012', '1', 'modelo 01', 'descripcion de la tablet 01', '1', '2018-06-11', '2018-06-10 09:47:28');
INSERT INTO `tablets` (`id`, `codigo`, `fabricante_id`, `modelo`, `descripcion`, `estado`, `ultimo_mante`, `fecregistro`) VALUES ('2', '100143', '1', 'modelo 01', 'descripcion de la tablet 02', '1', NULL, '2018-06-10 13:24:33');
INSERT INTO `tablets` (`id`, `codigo`, `fabricante_id`, `modelo`, `descripcion`, `estado`, `ultimo_mante`, `fecregistro`) VALUES ('3', '911', '1', 'modelo proyector 01', 'Descripcion del proyector 01', '1', NULL, '2018-06-11 11:29:33');


#
# TABLE STRUCTURE FOR: tablets_mantenimientos
#

DROP TABLE IF EXISTS `tablets_mantenimientos`;

CREATE TABLE `tablets_mantenimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tablet_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tecnico` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tablets_mantenimientos` (`id`, `tablet_id`, `fecha`, `tecnico`, `descripcion`) VALUES ('1', '1', '2018-06-11', 'Jhon Manrique', 'Cambuo de Carcasa');


#
# TABLE STRUCTURE FOR: usuarios
#

DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(200) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(100) NOT NULL,
  `cedula` int(11) NOT NULL,
  `sexo` varchar(100) NOT NULL,
  `rol_id` int(11) DEFAULT NULL,
  `estado` tinyint(1) NOT NULL,
  `imagen` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `usuarios` (`id`, `nombres`, `email`, `password`, `cedula`, `sexo`, `rol_id`, `estado`, `imagen`) VALUES ('1', 'Gean Carlos Mamani', 'gean@gmail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '10011', 'M', '1', '1', 'avatar11.png');
INSERT INTO `usuarios` (`id`, `nombres`, `email`, `password`, `cedula`, `sexo`, `rol_id`, `estado`, `imagen`) VALUES ('2', 'yony', 'yonybrondy17@gmail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '12912', 'M', '2', '1', 'imagen_masculino.jpg');


